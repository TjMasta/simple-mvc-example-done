module.exports.Cat = require('./Cat.js');
module.exports.Dog = require('./Dog.js');